(function() {
var index =  {"type":"data","keys":[{"name":"حضور و غیاب","type":"key","topics":[{"name":"حضور و غیاب","type":"topic","url":"ورود_به_سیستم_تایید_کارکرد/حضور_و_غیاب.htm"}],"keys":[]},{"name":"شروع","type":"key","topics":[{"name":"حضور و غیاب","type":"topic","url":"ورود_به_سیستم_تایید_کارکرد/حضور_و_غیاب.htm"}],"keys":[]},{"name":"نمایش کارکرد","type":"key","topics":[{"name":"حضور و غیاب","type":"topic","url":"ورود_به_سیستم_تایید_کارکرد/حضور_و_غیاب.htm"}],"keys":[]}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), index, { sync:true });
})();
