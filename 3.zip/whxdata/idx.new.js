(function() {
var index =  {"type":"index","chunkinfos":[{"type":"chunkinfo","first":"حضور و غیاب","last":"نمایش کارکرد","num":"3","node":"idata1"}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), index, { sync:true });
})();
