(function() {
var glossary =  {"type":"data","entrys":[{"type":"entry","name":"حضور و غیاب","value":"حضور و غیاب"}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), glossary, { sync:true });
})();
