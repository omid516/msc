(function() {
var glossary =  {"type":"glossary","chunkinfos":[{"type":"chunkinfo","first":"حضور و غیاب","last":"حضور و غیاب","num":"1","node":"gdata1"}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), glossary, { sync:true });
})();
